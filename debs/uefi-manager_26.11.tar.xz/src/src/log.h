/**********************************************************************
 *
 **********************************************************************
 * Copyright (C) 2024-2026 MX Authors
 *
 * Authors: Adrian <adrian@mxlinux.org>
 *          MX Linux <http://mxlinux.org>
 *
 * This is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this package. If not, see <http://www.gnu.org/licenses/>.
 **********************************************************************/
#pragma once

#include <QDebug>
#include <QFile>
#include <QString>

#include "common.h"

class Log
{
public:
    // An empty fileName uses uefi-manager.log in the user's private runtime directory
    explicit Log(const QString &fileName = {});
    static QString getLog();
    [[nodiscard]] static QByteArray readLog();
    static void flush();
    [[nodiscard]] static bool hasRelevantContent(qsizetype minimumLineCount = 1);
    static void messageHandler(QtMsgType type, const QMessageLogContext &, const QString &msg);

private:
    inline static QFile logFile;
};
