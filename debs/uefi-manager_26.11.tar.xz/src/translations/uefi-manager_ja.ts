<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ja">
<context>
    <name>Cmd</name>
    <message>
        <location filename="../src/cmd.cpp" line="173"/>
        <source>Administrator Access Required</source>
        <translation>アクセスするには管理者権限が必要です</translation>
    </message>
    <message>
        <location filename="../src/cmd.cpp" line="174"/>
        <source>This operation requires administrator privileges.</source>
        <translation>この操作を行うには、管理者権限が必要です。</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../src/mainwindow.ui" line="57"/>
        <location filename="../src/mainwindow.ui" line="198"/>
        <source>Please select the location of your installation:</source>
        <translation>インストール先を選択してください:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="71"/>
        <location filename="../src/mainwindow.ui" line="211"/>
        <source>Select drive:</source>
        <translation>ドライブの選択:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="78"/>
        <location filename="../src/mainwindow.ui" line="228"/>
        <source>Select partition:</source>
        <translation>パーティションの選択:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="249"/>
        <source>Frugal mode:</source>
        <translation>フルーガルモード:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="296"/>
        <source>Boot options:</source>
        <translation>起動オプション:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="129"/>
        <location filename="../src/mainwindow.ui" line="313"/>
        <source>UEFI entry name:</source>
        <translation>UEFI のエントリ名:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="20"/>
        <source>UEFI manager</source>
        <translation>UEFI マネージャ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="41"/>
        <source>EFI stub installer</source>
        <translation>EFI スタブインストーラ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="115"/>
        <source>Kernel to boot:</source>
        <translation>起動するカーネル:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="122"/>
        <source>Kernel options:</source>
        <translation>カーネルオプション:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="393"/>
        <source>About this application</source>
        <translation>このアプリケーションについて</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="396"/>
        <source>About...</source>
        <translation>情報...</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="402"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="418"/>
        <source>Quit application</source>
        <translation>アプリケーションの終了</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="421"/>
        <source>Close</source>
        <translation>閉じる</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="427"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="443"/>
        <source>Display help </source>
        <translation>ヘルプの表示</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="36"/>
        <source>Manage UEFI entries</source>
        <translation>UEFI エントリの管理</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="47"/>
        <source>This option copies the kernel and initrd files to ESP (EFI System Partition) and creates an UEFI entry that allows to boot the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="166"/>
        <source>Frugal EFI stub installer</source>
        <translation>フルーガル EFI スタブインストーラ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="172"/>
        <source>This option is meant to create a bootable entry for MX and antiX frugal installation, it creates an EFI boot entry for launching the installation directly, bypassing GRUB and other bootloaders. To boot using the created UEFI entry, access the UEFI boot selection menu at startup by pressing the appropriate key for your device (e.g., F12, F9, or Esc, depending on the manufacturer).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="446"/>
        <source>Help</source>
        <translation>ヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="452"/>
        <source>Alt+H</source>
        <translation>Alt+H</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="465"/>
        <location filename="../src/mainwindow.cpp" line="954"/>
        <location filename="../src/mainwindow.cpp" line="1714"/>
        <source>Next</source>
        <translation>次へ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.ui" line="503"/>
        <source>Back</source>
        <translation>戻る</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="778"/>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <location filename="../src/mainwindow.cpp" line="1527"/>
        <location filename="../src/mainwindow.cpp" line="1537"/>
        <source>UEFI Installer</source>
        <translation>UEFI インストーラ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="779"/>
        <source>A recent frugal install has been detected. Do you wish to add a UEFI entry direct to your UEFI system menu?</source>
        <translation>直近のフルーガルインストールを検出しました。UEFI システムメニューに直接 UEFI エントリを追加しますか？</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <source>Could not retrieve UUID for %1</source>
        <translation>%1 の UUID を取得できませんでした</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1033"/>
        <source>Enter passphrase to unlock %1 encrypted partition:</source>
        <translation>%1 の暗号化パーティションのロックを解除するには、パスフレーズを入力してください:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1038"/>
        <source>Passphrase entry cancelled or empty for %1</source>
        <translation>%1 のパスフレーズ入力がキャンセルされたか、空になっています</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <source>Could not open %1 LUKS container</source>
        <translation>%1 LUKS コンテナを開けませんでした</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1528"/>
        <source>Are you sure this is the MX or antiX Frugal installation location?
Missing mandatory files in directory: </source>
        <translation>これがMXまたはantiXのフルーガルインストール先で合っています？
ディレクトリ内に必須ファイルが欠落しています:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1592"/>
        <source>Not enough space on the EFI System Partition to copy the kernel and initrd files.</source>
        <translation>EFI システムパーティションの空き容量が不足しているので、カーネルと initrd ファイルをコピーできません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1651"/>
        <source>All fields are required</source>
        <translation>すべての項目が必須です</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1674"/>
        <source>Could not select ESP</source>
        <translation>ESP を選択できません</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1692"/>
        <source>About %1</source>
        <translation> %1 について</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>Select EFI file</source>
        <translation>EFI ファイルの選択</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="162"/>
        <source>EFI files (*.efi *.EFI)</source>
        <translation>EFI ファイル (*.efi *.EFI)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <location filename="../src/mainwindow.cpp" line="212"/>
        <location filename="../src/mainwindow.cpp" line="219"/>
        <location filename="../src/mainwindow.cpp" line="1026"/>
        <location filename="../src/mainwindow.cpp" line="1038"/>
        <location filename="../src/mainwindow.cpp" line="1044"/>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="174"/>
        <location filename="../src/mainwindow.cpp" line="185"/>
        <source>Could not find the source mountpoint for %1</source>
        <translation>%1 のソース・マウントポイントが見つかりません</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Set name</source>
        <translation>名前の設定</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="189"/>
        <source>Enter the name for the UEFI menu item:</source>
        <translation>UEFI メニューの項目名を入力します。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="212"/>
        <source>Selected file is not in an EFI directory</source>
        <translation>選択したファイルは EFI ディレクトリ内にありません</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="219"/>
        <source>Something went wrong, could not add entry.</source>
        <translation>問題が発生したため、項目を追加できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="810"/>
        <location filename="../src/mainwindow.cpp" line="853"/>
        <location filename="../src/mainwindow.cpp" line="1751"/>
        <source>Timeout: %1 seconds</source>
        <translation>タイムアウト: %1 秒</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="812"/>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <location filename="../src/mainwindow.cpp" line="859"/>
        <location filename="../src/mainwindow.cpp" line="1767"/>
        <source>Boot Next: %1</source>
        <translation>次回以降の既定の起動: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="814"/>
        <source>Boot Current: %1</source>
        <translation>現在の起動設定: %1</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="828"/>
        <source>You can use the Up/Down buttons, or drag &amp; drop items to change boot order.
- Items are listed in the boot order.
- Grayed out lines are inactive.</source>
        <translation>Up/Down ボタン、または項目のドラッグ＆ドロップで起動順序を変更できます。
- 項目は起動順に表示します。
- 灰色になっている行は有効ではありません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="839"/>
        <location filename="../src/mainwindow.cpp" line="902"/>
        <source>Set ac&amp;tive</source>
        <translation>アクティブにする(&amp;T)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="840"/>
        <source>&amp;Add entry</source>
        <translation>エントリの追加(&amp;A)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="841"/>
        <source>Boot &amp;next</source>
        <translation>次回の起動(&amp;N)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="842"/>
        <source>Move &amp;down</source>
        <translation>下へ移動(&amp;D)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="843"/>
        <source>&amp;Remove entry</source>
        <translation>エントリの削除(&amp;R)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="845"/>
        <source>Re&amp;set next</source>
        <translation>次回リセット(&amp;S)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="846"/>
        <source>Change &amp;timeout</source>
        <translation>タイムアウトの時間変更(&amp;T)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="847"/>
        <source>Move &amp;up</source>
        <translation>上へ移動(&amp;U)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="852"/>
        <location filename="../src/mainwindow.cpp" line="859"/>
        <source>not set, will boot using list order</source>
        <translation>設定せず、リスト順に起動</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="899"/>
        <source>Set &amp;inactive</source>
        <translation>非アクティブにする(&amp;I)</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="978"/>
        <source>Failed to open grub.entry file.</source>
        <translation>grub.entry ファイルを開くことができません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1695"/>
        <source>Tool for managing UEFI boot entries</source>
        <translation>UEFI ブートエントリを管理するためのツール</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1537"/>
        <source>Failed to read grub.entry file.</source>
        <translation>grub.entry ファイルの読み込みに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="963"/>
        <location filename="../src/mainwindow.cpp" line="1550"/>
        <source>Install</source>
        <translation>インストール</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1556"/>
        <source>Select Frugal Directory</source>
        <translation>フルーガルディレクトリを選択する</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1563"/>
        <source>No EFI System Partitions found.</source>
        <translation>EFI システムパーティションが見つかりません。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1568"/>
        <source>Select EFI System Partition</source>
        <translation>EFI システムパーティションを選択してください</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1569"/>
        <source>EFI System Partitions:</source>
        <translation>EFI システムパーティション:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1579"/>
        <source>No EFI System Partition selected</source>
        <translation>EFI システムパーティションが選択されていません</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1586"/>
        <source>Could not mount selected EFI System Partition</source>
        <translation>選択した EFI システムパーティションをマウントできません</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1614"/>
        <location filename="../src/mainwindow.cpp" line="1658"/>
        <source>Could not mount partition. Please make sure you selected the correct partition.</source>
        <translation>パーティションをマウントできません。正しいパーティションを選択したか確認してください。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1623"/>
        <source>No directory selected</source>
        <translation>ディレクトリが選択されていません</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1643"/>
        <location filename="../src/mainwindow.cpp" line="1680"/>
        <source>EFI stub installed successfully.</source>
        <translation>EFI スタブのインストールが完了しました。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1645"/>
        <location filename="../src/mainwindow.cpp" line="1682"/>
        <source>Failed to install EFI stub.</source>
        <translation>EFI スタブのインストールに失敗しました。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1693"/>
        <source>Version: </source>
        <translation>バージョン：</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1697"/>
        <source>Copyright (c) MX Linux</source>
        <translation>Copyright (c) MX Linux</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1698"/>
        <source>%1 License</source>
        <translation>%1 ライセンス</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1706"/>
        <source>%1 Help</source>
        <translation>%1 ヘルプ</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1736"/>
        <source>Something went wrong, could not save boot order.</source>
        <translation>問題が発生したので、起動順序を保存できませんでした。</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1746"/>
        <source>Set timeout</source>
        <translation>タイムアウトの設定</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1746"/>
        <source>Timeout in seconds:</source>
        <translation>タイムアウトの秒数:</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1785"/>
        <source>Removal confirmation</source>
        <translation>削除の確認</translation>
    </message>
    <message>
        <location filename="../src/mainwindow.cpp" line="1786"/>
        <source>Are you sure you want to delete this boot entry?
%1</source>
        <translation>本当にこの起動のエントリーを削除しても良いのですか？
%1</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/about.cpp" line="100"/>
        <source>License</source>
        <translation>ライセンス</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="101"/>
        <source>Changelog</source>
        <translation>更新履歴</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="102"/>
        <source>Cancel</source>
        <translation>キャンセル</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="126"/>
        <source>Error: Changelog file is missing.</source>
        <translation>エラー: Changlog ファイルが見つかりません。</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="128"/>
        <source>Error: Required utility &apos;zless&apos; is missing.</source>
        <translation>エラー: 必要なユーティリティ「zless」が見つかりません。</translation>
    </message>
    <message>
        <location filename="../src/about.cpp" line="135"/>
        <source>&amp;Close</source>
        <translation>閉じる(&amp;C)</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="85"/>
        <source>uefi-manager is a tool for managing UEFI boot entries</source>
        <translation>UEFI マネージャは、UEFI ブートエントリの管理ツールです</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="88"/>
        <source>Perform EFI Stub installation for frugal installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="66"/>
        <location filename="../src/main.cpp" line="95"/>
        <source>UEFI Manager</source>
        <translation>UEFI マネージャ</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="89"/>
        <source>Run in test mode (bypass UEFI detection for GUI testing).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../src/main.cpp" line="96"/>
        <source>This system doesn&apos;t seem to support UEFI, or was not booted in UEFI mode. Exiting.</source>
        <translation>このシステムは UEFI をサポートしていないか、または UEFI モードで起動していなかったようです。終了します。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="107"/>
        <source>Error</source>
        <translation>エラー</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="108"/>
        <source>You seem to be logged in as root, please log out and log in as normal user to use this program.</source>
        <translation>root でログインしているようです。このプログラムを使用するには、一度ログアウトして通常のユーザでログインしてください。</translation>
    </message>
    <message>
        <location filename="../src/main.cpp" line="113"/>
        <source>version:</source>
        <translation>バージョン:</translation>
    </message>
</context>
</TS>